API_ID = '29377263'
API_HASH = '8bf8093a4fe9c2eafd359e0a57e4a7cd'
BOT_TOKEN = '7626168937:AAFoc_VPw-kQj_xazxZvQsdCE3ys6q91zLg'
SESSIONS_DIR = 'sessions'
TEHRAN_TIMEZONE = 'Asia/Tehran'
MAX_CONCURRENT_UPDATES = 5
FORCE_JOIN_CHANNEL_USERNAME = "pdicko_team"
FORCE_JOIN_CHANNEL_ID = -1002549221513

PERSIAN_NUMERALS = '۰۱۲۳۴۵۶۷۸۹'
ENGLISH_NUMERALS = '0123456789'

ADMIN_USER_IDS = 7150795159


COIN_DB_CONFIG = {
    'host': '127.0.0.1',       # your DB host
    'port': 3306,              # your DB port
    'user': 'pdicko',        # your DB user
    'password': '3A5%1e72',  # your DB password
    'db': 'pdicko',           # your DB name
    'minsize': 5,
    'maxsize': 100000000,
    'autocommit': True,
}