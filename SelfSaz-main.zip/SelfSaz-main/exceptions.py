class DatabaseLockedError(Exception):
    """Exception raised when session file is locked"""
    pass