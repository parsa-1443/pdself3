# 🤖 SelfSaz Telegram Bot

<div dir="rtl">

# 🤖 ربات تلگرام سلف ساز

</div>

## 🌟 Features | امکانات

### 🤖 General Features | ویژگی‌های کلی
- 🎭 Multi-session support | پشتیبانی از چندین سشن
- 💰 Virtual coin system | سیستم سکه مجازی
- 🎰 Gambling games | بازی‌های شرط بندی
- 🎨 Sticker management | مدیریت استیکرها
- 📊 Referral system | سیستم دعوت از دوستان
- 🛡️ Admin panel | پنل مدیریت
- 📝 Support ticket system | سیستم تیکت پشتیبانی
- 🔔 AFK mode | حالت دور از دسترس
- 📥 Media downloader | دانلودر رسانه

### 🛠 Technical Features | ویژگی‌های فنی
- ⚡ Asynchronous operations | عملیات ناهمزمان
- 📦 Modular plugin system | سیستم ماژولار
- 🔄 Auto-update system | سیستم بروزرسانی خودکار
- 📝 Logging system | سیستم لاگ‌گیری
- 🔒 Session management | مدیریت سشن‌ها
- 🌐 Multi-language support | پشتیبانی از چند زبان

## 🚀 Installation & Setup | نصب و راه‌اندازی

### Prerequisites | پیش‌نیازها
- Python 3.8 or higher
- pip (Python package manager)
- MySQL Server (for database)
- Telegram API credentials

### Steps | مراحل

1. **Clone the repository** | **کلون کردن مخزن**
   ```bash
   git clone [your-repository-url]
   cd selfsaz
   ```

2. **Install dependencies** | **نصب پیش‌نیازها**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure the bot** | **پیکربندی ربات**
   - Copy `config.example.py` to `config.py`
   - Edit `config.py` with your credentials:
     - API_ID
     - API_HASH
     - BOT_TOKEN
     - Database configuration

4. **Set up the database** | **راه‌اندازی دیتابیس**
   - Create a MySQL database
   - Import the database schema
   - Update the database credentials in `config.py`

5. **Run the bot** | **اجرای ربات**
   ```bash
   python bot.py
   ```

## 📝 Usage | راهنمای استفاده

### Basic Commands | دستورات پایه
- `/start` - Start the bot | شروع کار با ربات
- `/help` - Show help message | نمایش راهنما
- `/balance` - Check your coins | مشاهده موجودی سکه‌ها
- `/gamble` - Play games | بازی کردن
- `/referral` - Get your referral link | دریافت لینک دعوت

### Admin Commands | دستورات مدیریتی
- `/admin` - Show admin panel | نمایش پنل مدیریت
- `/broadcast` - Send broadcast message | ارسال پیام همگانی
- `/ban` - Ban user | مسدود کردن کاربر
- `/unban` - Unban user | آزاد کردن کاربر

## ⚙️ Configuration | پیکربندی

### Environment Variables | متغیرهای محیطی
- `API_ID` - Your Telegram API ID
- `API_HASH` - Your Telegram API Hash
- `BOT_TOKEN` - Your Telegram Bot Token
- `DB_HOST` - Database host
- `DB_USER` - Database username
- `DB_PASS` - Database password
- `DB_NAME` - Database name

## 🤝 Contributing | مشارکت

Contributions are welcome! Please follow these steps:
1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📜 License | مجوز

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 📞 Contact | تماس

- Telegram: [@YourUsername](https://t.me/YourUsername)
- Email: your.email@example.com

<div dir="rtl">

## مشارکت

مشارکت‌های شما عزیزان باعث خوشحالی ماست! لطفاً مراحل زیر را دنبال کنید:
1. مخزن را فورک کنید
2. شاخه جدیدی برای قابلیت خود ایجاد کنید
3. تغییرات خود را کامیت بزنید
4. تغییرات را به شاخه خود پوش کنید
5. یک درخواست کشش (Pull Request) باز کنید

## مجوز

این پروژه تحت مجوز MIT منتشر شده است. برای جزئیات بیشتر فایل [LICENSE](LICENSE) را مشاهده کنید.

## تماس با ما

- تلگرام: [نام کاربری شما](https://t.me/YourUsername)
- ایمیل: your.email@example.com

</div>

---

<div align="center">
  Made with ❤️ by Your Name
</div>
